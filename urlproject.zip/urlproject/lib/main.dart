import 'package:flutter/material.dart';
import 'package:urlproject/callPage.dart';
import 'package:urlproject/emailPage.dart';
import 'package:urlproject/homePage.dart';
import 'package:urlproject/smsPage.dart';
import 'package:urlproject/website.dart';


void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme:ThemeData(
        // brightness: Brightness.dark
        primarySwatch: Colors.lightGreen,
      ),
      //onGenerateRoute: route.controller,initialRoute: route.urlHomePage,
      debugShowCheckedModeBanner: false,
      home:HomePage(),
      routes: {
        '/calls': (context) => const CallPage(),
        '/sms': (context) => const SmsPage(),
        '/mails': (context) => const EmailPage(),
        '/webs': (context) => const Website()
      },
    );
  }
}