import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  var selectedItem = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Url page'),
        centerTitle: true,
        actions: [
          PopupMenuButton(
            onSelected: (value) {
              setState(() {
                selectedItem = value.toString();
              });
              print(value);
              Navigator.pushNamed(context, value.toString());
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(
                      Icons.call,
                      color: Colors.black,
                    ),
                    Text(" call"),
                  ],
                ),
                value:'/calls',
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(
                      Icons.mail,
                      color: Colors.black,
                    ),
                    Text(" mail"),
                  ],
                ),
                value:'/mail',
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(
                      Icons.language,
                      color: Colors.black,
                    ),
                    Text(" website"),
                  ],
                ),
                value:'/website',
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(
                      Icons.sms,
                      color: Colors.black,
                    ),
                    Text(" sms"),
                  ],
                ),
                value:'/sms',
              ),
            ],
          ),
        ],
      ),
      body: Center(
        child:Text(selectedItem),
      ),
    );
  }
}
