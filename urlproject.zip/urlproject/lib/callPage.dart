import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';


class CallPage extends StatefulWidget {
  const CallPage({Key? key}) : super(key: key);

  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  String _phone = '';
  Future<void>? _launched;
  @override
  Widget build(BuildContext context) {
    return Form(
        child: Scaffold(
        body:ListView(
        children: [
          Column(
            children: [
              TextFormField(
                onChanged: (String text)=>_phone=text,
                decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(),
                    border: OutlineInputBorder(),
                    labelText: "Enter your No."
                ),
                keyboardType: TextInputType.number,
              ),
              ElevatedButton.icon(
                onPressed: () => setState(() {
                  launch('tel:$_phone');
                }),
                icon:const Icon(Icons.call),
                label: const Text('sent'),
              ),
            ],
          ),
        ],
      ),
    ),
    );
  }
}
